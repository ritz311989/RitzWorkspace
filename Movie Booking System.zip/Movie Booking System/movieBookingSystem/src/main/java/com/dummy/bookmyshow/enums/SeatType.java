package com.dummy.bookmyshow.enums;

public enum SeatType {
	NORMAL, VIP, EXECUTIVE, ROYAL, ENCLINER
}
