package com.dummy.bookmyshow.enums;

public enum UserType {
ADMIN,NORMAL
}
