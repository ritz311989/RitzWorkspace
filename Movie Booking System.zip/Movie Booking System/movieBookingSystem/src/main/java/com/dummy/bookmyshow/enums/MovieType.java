package com.dummy.bookmyshow.enums;

public enum MovieType {
	COMEDY, CRIME, SUSPENSE, ROMANCE, THILLER
}
