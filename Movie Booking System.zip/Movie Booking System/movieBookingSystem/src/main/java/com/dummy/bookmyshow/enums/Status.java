package com.dummy.bookmyshow.enums;

public enum Status {
	SUCCESS,FAILED,PROCESSING

}
