package com.dummy.bookmyshow.enums;

public enum NotificationType {
MOBILEPHONE,EMAIL,WATSAPP
}
