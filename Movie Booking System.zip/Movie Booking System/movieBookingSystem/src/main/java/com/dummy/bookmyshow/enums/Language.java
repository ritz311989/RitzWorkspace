package com.dummy.bookmyshow.enums;

public enum Language {
	HINDI, ENGLISH

}
