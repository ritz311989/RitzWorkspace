package com.dummy.bookmyshow.enums;

public enum TheaterType {
	IMAX, PVR, LOCAL
}
